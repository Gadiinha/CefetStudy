<!DOCTYPE html>
<meta charset= utf-8>

<html>
  <link rel="stylesheet" type="text/css" href="style.css">
    <main>
    
      <main>
    
        <div style="overflow: hidden;">
        <div style>
		      <p></p>
      <h1><strong>Bem vindo ao Site Study Cefet</strong></h1>
      <br> <img src="Read.png" alt="Descrição da imagem" style="float: right; margin-left: 50px; width: 300px; height: auto;"> </div>
      <div style="text-align: left;">
      <p>Este é um site de exemplo com um cabeçalho azul e alguns botões com link.</p>
      <p> Acompanhe todas as nossas dicas de como se preparar para o CEFET, mas antes vale apenas <br>lembrar a importância da instituição 
        e o peso que carrega no ensino do Brasil, por isso o Cefet<br> se destaca entre as melhores escolas do Brasil.</p>
        <p>Acima de tudo o CEFET é uma instituição de ensino pública federal que oferece o ensino médio,<br> cursos técnicos,
         cursos de graduação e pós-graduação. </p>
         <p>Nosso objetivo é fornecer aos alunos as ferramentas e informações necessárias para uma experiência<br> universitária
           gratificante e bem-sucedida. Além disso, nosso fórum de discussão e seção de blog <br>incentivam a comunidade de alunos
            a se conectar e compartilhar dicas e conselhos. Seja bem-vindo e <br>aproveite ao máximo sua jornada acadêmica.
      </p></div>
	  
	  <hr class="horizontal-bar">
	  
      <div style="overflow: hidden;">
      
    </main>
    <img src="publico.png" alt="Descrição da imagem" style="float: left; margin-right: 50px; width: 200px; height: auto;"> </div>
    <div style="text-align: left;">

    <h1><strong> Publico Alvo </strong></h1>

    <br>
    <p> Site criado com o objetivo de fornecer aos alunos, recém ingressados no Cefet, as ferramentas <br> e informações necessárias para uma experiência universitária gratificante e bem-sucedida. 
      Oferecendo uma variedade de recursos úteis, desde orientação acadêmica e dicas de estudo até informações 
      sobre a vida universitária e recursos de aprendizagem. </p>
	
    </br></div>
	
	<hr class="horizontal-bar">
	
	<div style="overflow: hidden;">
      <div style 
	  <p></p>
      <h1><strong>Grupo de acessibilidade</strong></h1>
       <br> <img src="daltonico.png" alt="Descrição da imagem" style="float: right; margin-right: 50px; width: 160px; height: auto;"> </div>
    <div style="text-align: left;">
	  <h2>Principalmente para pessoas com daltonismo</h2>
      <p>Para construir um texto acessível</p>

	  <p>A formatação de um texto pode, muitas vezes, não funcionar para todas as pessoas. Em muitos casos, a fonte escolhida ou a maneira de destacar uma informação podem tornar o conteúdo confuso,
	  já que não raro um daltônico não percebe a diferença entre uma cor e outra. Para solucionar esse problema, duas dicas muito simples podem ser bastante úteis:</p>
	  <ul><li>Quando for destacar uma informação, não faça  apenas por meio da mudança de cor, sublinhe a frase. Assim, uma pessoa com daltonismo consegue diferenciar as sentenças que estão
	  destacadas daquelas que não estão.</l1>
	  <li>Preste atenção no contraste entre o fundo da página e a fonte escolhida, pois isso pode em muitos casos dificultar a leitura.</li></ul> 

      </p></div>
    </div>
    </main>
    <hr class="horizontal-bar">

    </div>
    
    <div style="text-align: center;">
    <h1>
   <strong>Acesso rápido </h1></strong></p></div>
   <div class="post-it" style="overflow: hidden;">
      <div class="post-it-header">
        
        <a href="https://www.cefetmg.br/"><img src="Cefet-MG.png" alt="Ícone" style="float: center; margin-left: 50px; width: 100px;"></a> </div>
        <p> Site do Cefet - Contagem, estão todas informações referentes ao Campus, cursos, administração, dentre outros.<p>
      </div>
    </div>
    
    <div class="post-it">
      <div class="post-it-header">
          <a href="https://ava.cefetmg.br/login/index.php"><img src="moodle.png" alt="Ícone" style="float: center; margin-left: 55px; width: 100px;"></a></div>

        <p >Ava ou Moodle, nele você
          acessa as disciplinas, obtém conteúdos de estudo e faz a entrega atividades.</p>
      </div>
    </div>
        
    <div class="post-it">
      <div class="post-it-header">
        <a href="https://selecaobolsistas.cefetmg.br/home/"> <img src="dde.png" alt="Ícone" style="float: center; margin-left: 30px; width: 150px;" ></a></div>
        <p> Seleção de bolsistas: esse é o Sistema de bolsas do Cefet, nele você observa o seu processo, suas informações, dentre outros.<p>
      </div>
     
    </div>

    <div class="post-it">
      <div class="post-it-header">
          <a href="https://sig.cefetmg.br/sigaa/logar.do?dispatch=logOff"><img src="sigaa.png" alt="Ícone" style="float: left; margin-left: 30px; width: 150px;"></a></div>
        <br><p> Sigaa Web: acessa o boletim, as disciplinas, entrega atividades, etc.<p>
      </div>
   
    </main>
    </div>
  </body>
</html>